package com.example.futkart

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
