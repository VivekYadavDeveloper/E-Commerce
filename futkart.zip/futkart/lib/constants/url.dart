const String baseurl = "https://futcart.com/wp-json/wc";
const String signup = "/v3/customers";
const String productlist = "/v3/products";
const String categoryProductlist = "/v3/products?category=";
const String orderlistUrl = "/v3/orders?customer=";

const String userdata = "/v3/customers/";
const String getresetcode = "https://futcart.com/wp-json/bdpwr/v1/reset-password";
const String validateresetcode = "https://futcart.com/wp-json/bdpwr/v1/validate-code";
const String resetpassword = "https://futcart.com/wp-json/bdpwr/v1/set-password";


const String singleProduct = "/v3/products/";
const String productCategory = "/v3/products/categories";
const String loginToken ="https://futcart.com/wp-json/api/v1/token";




const termAndCondition = "https://futcart.com/term-and-conditions/";
const privacyAndPolicy = "https://futcart.com/privacy-policy";
const aboutUs = "sites.google.com/view/quizrank/home";


//////////////////////////////////////////////////////  razorpay Key
const String rzpKey = 'rzp_test_cGGXwbUTKhIaLv';











const String complete_profile = "/api/auth/login";
const String forgot_password = "/api/auth/userforgotPassword";
const String forgot_password_otp = "/api/auth/userforgotPassword";
const String register = "/api/auth/register";
const String verify_account = "/api/auth/verifyuserDetails";
const String verify_phone = "/api/auth/verifyMobileNumber";
const String verify_phone_otp = "/api/auth/verifyPhoneOtp";


const String username = 'ck_5b3c95cfe93ece02ad0663ed6a0a6197b602db04';
const String password = 'cs_7c02f989d21e1c034b6c18332e01b80847776eb3';