import 'package:flutter/material.dart';

Colors background = Colors.white as Colors; 
Colors otp_backcolor = const Color(0xffE3EBEE) as Colors; 
// Colors otp_backcolor = Colors.white as Colors; 



///   local image data
String applogoImage = "images/Futcart-logo.png";